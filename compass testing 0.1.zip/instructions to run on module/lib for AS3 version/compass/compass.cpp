#include <Wire.h>
#include "compass.h"
#define addr 0x0C //I2C Address 
#include <Arduino.h>
int16_t x;
int16_t y;
int16_t z;

bool compass::begin(){
Wire.begin(); 
Wire.beginTransmission(addr);
Wire.write(0x1B);
Wire.write(0x98);
Wire.endTransmission();
Wire.beginTransmission(addr); 
Wire.write(0x1C);
Wire.write(0x0C);
Wire.endTransmission();
Wire.beginTransmission(addr);
Wire.write(0x1E);
Wire.write(0x90);
Wire.endTransmission();
return true;
}
float compass::read(){
Wire.beginTransmission(addr); 
Wire.write(0x10);
Wire.endTransmission();
Wire.requestFrom(addr, 6);

if (Wire.available()==6) {
x = Wire.read(); x |= Wire.read()<<8; x=x*1.2;
y = Wire.read(); y |= Wire.read()<<8; y=y*1.2;
z = Wire.read(); z |= Wire.read()<<8; z=z*1.2;
} 
//atan2(y,x)
float bearing=((atan2(y,x))*180)/PI;//values will range from +180 to -180 degrees
if (bearing < 0)  { bearing = 360 + bearing; }
return bearing; 
}


