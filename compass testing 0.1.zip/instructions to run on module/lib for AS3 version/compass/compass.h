class compass{
public:


float read();
bool begin();

};
