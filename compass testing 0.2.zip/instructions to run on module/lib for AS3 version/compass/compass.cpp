#include <compass.h>
#include <Wire.h>

compass::compass(void){
}

int16_t ax=0;
int16_t ay=0;
int16_t az=0;
int16_t mx=0;
int16_t my=0;
int16_t mz=0;
int16_t m_x_min=0;
int16_t m_x_max=0;
int16_t m_y_min=0;
int16_t m_y_max=0;
int16_t m_z_min=0;
int32_t m_z_max=0;

byte i2c_1;
byte i2c_2;
int compass::begin(int a, int b){
Wire.begin();
i2c_1 = a;
i2c_2 = b;
Wire.beginTransmission(i2c_1);
Wire.write(0x23);
Wire.write(0x08);
Wire.endTransmission();
Wire.beginTransmission(i2c_1);
Wire.write(0x20);
Wire.write(0x47);
Wire.endTransmission();
Wire.beginTransmission(i2c_2);
Wire.write(0x00);
Wire.write(0x0C);
Wire.endTransmission();
Wire.beginTransmission(i2c_2);
Wire.write(0x01);
Wire.write(0x20);
Wire.endTransmission();
Wire.beginTransmission(i2c_2);
Wire.write(0x02);
Wire.write(0x00);
Wire.endTransmission();
}




float compass::read(void){
Wire.beginTransmission(i2c_1);
Wire.write(0xA8);
Wire.endTransmission();
Wire.requestFrom(i2c_1,(byte)6);

byte x_lb_a=Wire.read();
byte x_hb_a=Wire.read();
byte y_lb_a=Wire.read();
byte y_hb_a=Wire.read();
byte z_lb_a=Wire.read();
byte z_hb_a=Wire.read();

ax=(int16_t)(x_hb_a<<8|x_lb_a);
ay=(int16_t)(y_hb_a<<8|y_lb_a);
az=(int16_t)(z_hb_a<<8|z_lb_a);

Wire.beginTransmission(i2c_2);
Wire.write(0x03);
Wire.endTransmission();
Wire.requestFrom(i2c_2,(byte)6);

byte xlm,xhm,ylm,yhm,zlm,zhm;

xhm=Wire.read();
xlm=Wire.read();
zhm=Wire.read();
zlm=Wire.read();
yhm=Wire.read();
ylm=Wire.read();

mx=(int16_t)(xhm<<8|xlm);
my=(int16_t)(yhm<<8|ylm);
mz=(int16_t)(zhm<<8|zlm);

int32_t temp_m_x=mx;
int32_t temp_m_y=my;
int32_t temp_m_z=mz;

temp_m_x-=((int32_t)m_x_min+m_x_max)/2;
temp_m_y-=((int32_t)m_y_min+m_y_max)/2;
temp_m_z-=((int32_t)m_z_min+m_z_max)/2;

float temp_x=0;
float temp_y=0;
float temp_z=0;
float temp_x_2=0;
float temp_y_2=0;
float temp_z_2=0;

temp_x=(temp_m_y*az)-(temp_m_z*ay);
temp_y=(temp_m_z*ax)-(temp_m_x*az);
temp_z=(temp_m_x*ay)-(temp_m_y*ax);

float temp_m=sqrt((temp_x*temp_x)+(temp_y*temp_y)+(temp_z*temp_z));
temp_x /= temp_m;
temp_y /= temp_m;
temp_z /= temp_m;
temp_x_2 = (ay*temp_z)-(az*temp_y);
temp_y_2 = (az*temp_x)-(ax*temp_z);
temp_z_2 = (ax*temp_y)-(ay*temp_x);
temp_m = sqrt((temp_x_2*temp_x_2)+(temp_y_2*temp_y_2)+(temp_z_2*temp_z_2));
temp_x_2 /= temp_m;
temp_y_2 /= temp_m;
temp_z_2 /= temp_m;
int from_x=0;
int from_y=-1;
int from_z=0;   
float bearing=atan2((temp_x*from_x)+(temp_y*from_y)+(temp_z*from_z),(temp_x_2*from_x)+(temp_y_2*from_y)+(temp_z_2*from_z))*180/3.14;
if(bearing<0){
bearing += 360;
}
return bearing;
}