#include "Arduino.h"

class compass{
public:
compass(void);
int begin(int a,int b);
float read(void);

};